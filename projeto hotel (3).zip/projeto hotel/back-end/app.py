import os
from flask import Flask, send_from_directory

#caminho base do projeto (uma pasta acima de backend)
BASE_DIR = os.path.abspath (os.path.join(os.path.dirname(__file__), ".."))

#pasta frondend (HTML e JS)
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")

#pasta static (css)
STATIC_DIR = os.path.join(BASE_DIR,"static")

app = Flask(__name__,static_folder=STATIC_DIR,static_url_path="/"+STATIC_DIR)

@app.route("/")
def home():
    return send_from_directory(FRONTEND_DIR,"index.html")


@app.route("/")
def consulta():
    return send_from_directory(FRONTEND_DIR,"consulta.html")

@app.route("/alterar")
def alterar_pege():
    return send_from_directory(FRONTEND_DIR,"alterar.html")


if __name__ == "__main__":
 print("BASE_DIR:", BASE_DIR)
 print("FRONTEND_DIR:", STATIC_DIR)
 print("STATIC_DIR:",STATIC_DIR)
app.run(debug=True)


